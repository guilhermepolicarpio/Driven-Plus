import styled from 'styled-components';
import { useNavigate } from "react-router-dom";
import UserContext from './UserContext';
import { useState,useContext,useEffect } from "react";
import { getPlan } from '../services/Services';

export default function Confirmation(){
const [dataPlan, setDataPlan] = useState(null);
const [isModalVisible, setIsModalVisible]= useState(false);
const [load, setLoad]= useState(false);
const [values, setValues] = useState({ membershipId: '', cardName: '', cardNumber: '', securityNumber: '' , expirationDate: ''});
const { userInfo,plan, setPlan } = useContext(UserContext);
let navigate = useNavigate();


const Change = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
    }

useEffect(() => {   
    console.log(userInfo.token)
    const config = {
        headers: {
            "Authorization": `Bearer ${userInfo.token}`,
        }
    }
    setLoad(false)
    getPlan(plan,config).then((r) => {
    setDataPlan(r.data)
    setLoad(true)
}
)
.catch((r) =>{
    console.log(r)
});
},[]);

if(load===false){    return "carregando" }
return(
<Page>
    <ion-icon name="arrow-back-sharp" onClick ={() => navigate("/subscriptions")} ></ion-icon>
<Box>
   <img src={dataPlan.image} alt=""/>
   <p>{dataPlan.name} </p>
</Box>
   <Benefits>
    <ion-icon name="reader-outline"> </ion-icon>
    <h1> Beneficios</h1>
    </Benefits>

    {dataPlan.perks.map((value,index) =>(
     <PlanBenefits key={value.id}>
        <h2>{index+1}.</h2>
        <h2>{value.title}</h2> 
      </PlanBenefits>    
    ))}

    <PriceBox>
        <ion-icon name="cash-outline"> </ion-icon>
        <h1>Preço</h1>
    </PriceBox>
    <Price>
         <h1> R$ {dataPlan.price} cobrados separadamente</h1>
    </Price>
    <Forms >
        <Input type="text"  placeholder=" Nome impresso no cartão" onChange={Change} name='cardName'  />
        <Input type="text"  placeholder=" Digitos do cartão" onChange={Change} name='cardNumber' />
        <Security>
            <InputSecurity type="password"  placeholder=" Código de segurança" onChange={Change} name='securityNumber'  />
            <InputSecurity type="text"  placeholder=" Validade **/**" onChange={Change} name='expirationDate' />
        </Security>
        <button onClick={() => setIsModalVisible(!isModalVisible)}>
        <p> ASSINAR</p>
    </button>
    {isModalVisible ?
    <Modal>
        <ModalBox>
        <h1>
            Tem certeza que deseja assinar o plano {dataPlan.name} ({dataPlan.price} )?
        </h1>
        </ModalBox>
    </Modal> 
     :
    
    <></>}
    </Forms>

</Page>
)
}

const Page = styled.div`
position: relative;
padding: 15px 0px 0px 15px;
    ion-icon{
    color: white;
    width: 28px;
    height: 32px;
    cursor:pointer; 
    }
`;

const Box = styled.div`
padding-top:37px ;
display: flex;
flex-direction: column;
align-items: center;
width:100%;

p{
padding: 10px 0px 0px 0px;
font-weight: 700;
font-size: 32px;
line-height: 38px;
color: #FFFFFF;
}

ion-icon{
    color: #FF4791;;
}
`;

const Benefits= styled.div`
display: flex;
align-items: center;
justify-content: flex-start;
padding: 22px 0px 8px 40px;
ion-icon{
    color: #FF4791;;
}
h1{
color: #FFFFFF;
font-weight: 400;
font-size: 16px;
line-height: 19px;
}
`;

const PriceBox= styled.div`
display: flex;
align-items: center;
justify-content: flex-start;
padding: 22px 0px 8px 40px;
ion-icon{
    color: #FF4791;;
}
h1{
color: #FFFFFF;
font-weight: 400;
font-size: 16px;
line-height: 19px;
}
`;

const Price= styled.div`
display: flex;
padding: 0px 0px 8px 40px;
h1{
color: #FFFFFF;
font-weight: 400;
font-size: 16px;
line-height: 19px;
}
`;

const PlanBenefits= styled.div`
display: flex;
align-items: center;
justify-content: flex-start;
padding: 4px 0px 0px 40px;

h2{
color: #FFFFFF;
font-weight: 400;
font-size: 16px;
line-height: 19px;
padding-right: 5px;
}
`;

const Input= styled.input`
display: flex;
justify-content: center;
width:80%;
height:52px;
color: #DBDBDB;
font-size: 19.976px;
line-height: 25px;
background: #FFFFFF;
border: 1px solid #D5D5D5;
border-radius: 8px;
margin-bottom: 15px;

`;

const Forms = styled.form`

display: flex;
flex-direction: column;
align-items: center;
width: 100%;

button{
display: flex;
justify-content: center;
align-items: center;
width: 80%;
height: 52px;
font-size: 19.976px;
line-height: 25px;
border: 1px solid #D5D5D5;
background: #FF4791;
border-radius: 8px;
cursor:pointer; 
}
p{
color:white;
}
`;

const Security = styled.div`
display: flex;
justify-content: space-between;
width:80%;

`;

const InputSecurity= styled.input`
display: flex;
justify-content: center;
width:45%;
height:52px;
color: #DBDBDB;
font-size: 16px;
line-height: 25px;
background: #FFFFFF;
border: 1px solid #D5D5D5;
border-radius: 8px;
margin-bottom: 15px;
`;

const Modal= styled.div`
width: 100%;
height:100%;
display: flex;
justify-content: center;
z-index:2;
background-color: rgba(0,0,0,0.8);
`;

const ModalBox= styled.div`

width: 40%;
height:20%;
position: absolute;
z-index:2;
background-color: #FFFFFF;
color: #000000;
margin: 0 auto;
`;